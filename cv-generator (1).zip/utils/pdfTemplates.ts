import { type PDFDocument, type PDFPage, type PDFFont, rgb } from "pdf-lib"

type CVData = {
  name: string
  email: string
  education: { institution: string; degree: string; year: string }[]
  skills: string[]
  experience: { company: string; position: string; startDate: string; endDate: string; description: string }[]
}

export async function generateClassicTemplate(pdfDoc: PDFDocument, page: PDFPage, font: PDFFont, data: CVData) {
  const { width, height } = page.getSize()
  let yOffset = height - 50

  // Add name
  page.drawText(data.name, { x: 50, y: yOffset, size: 24, font, color: rgb(0.1, 0.1, 0.1) })
  yOffset -= 30

  // Add email
  page.drawText(data.email, { x: 50, y: yOffset, size: 12, font, color: rgb(0.3, 0.3, 0.3) })
  yOffset -= 20

  // Add education
  page.drawText("Education", { x: 50, y: yOffset, size: 16, font, color: rgb(0.2, 0.2, 0.2) })
  yOffset -= 20
  data.education.forEach((edu) => {
    page.drawText(`${edu.institution} - ${edu.degree} (${edu.year})`, {
      x: 60,
      y: yOffset,
      size: 10,
      font,
      color: rgb(0.3, 0.3, 0.3),
    })
    yOffset -= 15
  })
  yOffset -= 10

  // Add skills
  page.drawText("Skills", { x: 50, y: yOffset, size: 16, font, color: rgb(0.2, 0.2, 0.2) })
  yOffset -= 20
  page.drawText(data.skills.join(", "), {
    x: 60,
    y: yOffset,
    size: 10,
    font,
    color: rgb(0.3, 0.3, 0.3),
    maxWidth: width - 100,
  })
  yOffset -= 30

  // Add experience
  page.drawText("Experience", { x: 50, y: yOffset, size: 16, font, color: rgb(0.2, 0.2, 0.2) })
  yOffset -= 20
  data.experience.forEach((exp) => {
    page.drawText(`${exp.company} - ${exp.position}`, { x: 60, y: yOffset, size: 12, font, color: rgb(0.2, 0.2, 0.2) })
    yOffset -= 15
    page.drawText(`${exp.startDate} - ${exp.endDate}`, { x: 60, y: yOffset, size: 10, font, color: rgb(0.3, 0.3, 0.3) })
    yOffset -= 15
    page.drawText(exp.description, {
      x: 60,
      y: yOffset,
      size: 10,
      font,
      color: rgb(0.3, 0.3, 0.3),
      maxWidth: width - 100,
    })
    yOffset -= 30
  })
}

export async function generateModernTemplate(pdfDoc: PDFDocument, page: PDFPage, font: PDFFont, data: CVData) {
  const { width, height } = page.getSize()
  let yOffset = height - 50

  // Add a colored header
  page.drawRectangle({
    x: 0,
    y: height - 100,
    width: width,
    height: 100,
    color: rgb(0.2, 0.6, 0.8),
  })

  // Add name
  page.drawText(data.name, { x: 50, y: height - 70, size: 28, font, color: rgb(1, 1, 1) })

  // Add email
  page.drawText(data.email, { x: 50, y: height - 95, size: 12, font, color: rgb(1, 1, 1) })

  // Add sections
  const sectionTitles = ["Education", "Skills", "Experience"]
  sectionTitles.forEach((title, index) => {
    yOffset = height - 120 - index * 180
    page.drawText(title, { x: 50, y: yOffset, size: 18, font, color: rgb(0.2, 0.6, 0.8) })
    page.drawLine({
      start: { x: 50, y: yOffset - 5 },
      end: { x: width - 50, y: yOffset - 5 },
      thickness: 1,
      color: rgb(0.8, 0.8, 0.8),
    })
  })

  // Add content for each section
  yOffset = height - 150
  data.education.forEach((edu) => {
    page.drawText(`${edu.institution} - ${edu.degree} (${edu.year})`, {
      x: 60,
      y: yOffset,
      size: 10,
      font,
      color: rgb(0.2, 0.2, 0.2),
    })
    yOffset -= 15
  })

  yOffset = height - 330
  page.drawText(data.skills.join(", "), {
    x: 60,
    y: yOffset,
    size: 10,
    font,
    color: rgb(0.2, 0.2, 0.2),
    maxWidth: width - 100,
  })

  yOffset = height - 510
  data.experience.forEach((exp) => {
    page.drawText(`${exp.company} - ${exp.position}`, { x: 60, y: yOffset, size: 12, font, color: rgb(0.2, 0.2, 0.2) })
    yOffset -= 15
    page.drawText(`${exp.startDate} - ${exp.endDate}`, { x: 60, y: yOffset, size: 10, font, color: rgb(0.4, 0.4, 0.4) })
    yOffset -= 15
    page.drawText(exp.description, {
      x: 60,
      y: yOffset,
      size: 10,
      font,
      color: rgb(0.2, 0.2, 0.2),
      maxWidth: width - 100,
    })
    yOffset -= 30
  })
}

export async function generateCreativeTemplate(pdfDoc: PDFDocument, page: PDFPage, font: PDFFont, data: CVData) {
  const { width, height } = page.getSize()
  let yOffset = height - 50

  // Add a diagonal background
  page.drawPolygon(
    [
      { x: 0, y: 0 },
      { x: width, y: 0 },
      { x: 0, y: height },
    ],
    { color: rgb(0.9, 0.3, 0.3) },
  )

  // Add name
  page.drawText(data.name, { x: 50, y: height - 100, size: 36, font, color: rgb(1, 1, 1) })

  // Add email
  page.drawText(data.email, { x: 50, y: height - 140, size: 14, font, color: rgb(0.2, 0.2, 0.2) })

  // Add sections
  const sectionTitles = ["Education", "Skills", "Experience"]
  sectionTitles.forEach((title, index) => {
    yOffset = height - 180 - index * 160
    page.drawText(title, { x: 50, y: yOffset, size: 24, font, color: rgb(0.9, 0.3, 0.3) })
  })

  // Add content for each section
  yOffset = height - 220
  data.education.forEach((edu) => {
    page.drawText(`${edu.institution}`, { x: 60, y: yOffset, size: 12, font, color: rgb(0.2, 0.2, 0.2) })
    yOffset -= 20
    page.drawText(`${edu.degree} (${edu.year})`, { x: 60, y: yOffset, size: 10, font, color: rgb(0.4, 0.4, 0.4) })
    yOffset -= 25
  })

  yOffset = height - 380
  const skillsPerLine = 3
  for (let i = 0; i < data.skills.length; i += skillsPerLine) {
    const skillLine = data.skills.slice(i, i + skillsPerLine).join(" • ")
    page.drawText(skillLine, { x: 60, y: yOffset, size: 10, font, color: rgb(0.2, 0.2, 0.2) })
    yOffset -= 20
  }

  yOffset = height - 540
  data.experience.forEach((exp) => {
    page.drawText(`${exp.company} - ${exp.position}`, { x: 60, y: yOffset, size: 14, font, color: rgb(0.2, 0.2, 0.2) })
    yOffset -= 20
    page.drawText(`${exp.startDate} - ${exp.endDate}`, { x: 60, y: yOffset, size: 10, font, color: rgb(0.4, 0.4, 0.4) })
    yOffset -= 15
    page.drawText(exp.description, {
      x: 60,
      y: yOffset,
      size: 10,
      font,
      color: rgb(0.2, 0.2, 0.2),
      maxWidth: width - 100,
    })
    yOffset -= 30
  })
}

