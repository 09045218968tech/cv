"use client"

import { useForm } from "react-hook-form"
import { toast } from "react-toastify"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"

type ContactFormData = {
  linkedin?: string
  twitter?: string
  facebook?: string
  github?: string
  website?: string
}

export default function ContactForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ContactFormData>()

  const onSubmit = (data: ContactFormData) => {
    console.log(data)
    toast.success("Contact information saved successfully!")
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="linkedin">LinkedIn Profile URL</Label>
        <Input id="linkedin" placeholder="(link unavailable)" {...register("linkedin")} />
      </div>

      <div>
        <Label htmlFor="twitter">Twitter Handle</Label>
        <Input id="twitter" placeholder="@yourhandle" {...register("twitter")} />
      </div>

      <div>
        <Label htmlFor="facebook">Facebook Profile URL</Label>
        <Input id="facebook" placeholder="(link unavailable)" {...register("facebook")} />
      </div>

      <div>
        <Label htmlFor="github">GitHub Profile URL</Label>
        <Input id="github" placeholder="(link unavailable)" {...register("github")} />
      </div>

      <div>
        <Label htmlFor="website">Personal Website/Blog URL</Label>
        <Input id="website" placeholder="(link unavailable)" {...register("website")} />
      </div>

      <Button type="submit">Save Contact Information</Button>
    </form>
  )
}

