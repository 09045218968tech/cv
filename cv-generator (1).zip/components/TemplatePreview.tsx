import Image from "next/image"
import { Button } from "@/components/ui/button"

type TemplatePreviewProps = {
  id: number
  name: string
  image: string
  onSelect: (id: number) => void
}

export function TemplatePreview({ id, name, image, onSelect }: TemplatePreviewProps) {
  return (
    <div className="border rounded-lg overflow-hidden shadow-md">
      <Image src={image || "/placeholder.svg"} alt={name} width={300} height={400} className="w-full h-auto" />
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2">{name}</h3>
        <Button onClick={() => onSelect(id)}>Select Template</Button>
      </div>
    </div>
  )
}

