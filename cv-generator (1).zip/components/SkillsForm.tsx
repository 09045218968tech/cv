"use client"

import { useForm } from "react-hook-form"
import { toast } from "react-toastify"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

type SkillsFormData = {
  technicalSkills: string
  softSkills: string
  languageProficiency?: string
  certifications?: string
}

export default function SkillsForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SkillsFormData>()

  const onSubmit = (data: SkillsFormData) => {
    console.log(data)
    toast.success("Skills saved successfully!")
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="technicalSkills">Technical Skills *</Label>
        <Textarea
          id="technicalSkills"
          placeholder="e.g., JavaScript, Python, HTML/CSS"
          {...register("technicalSkills", { required: "Technical skills are required" })}
        />
        {errors.technicalSkills && <p className="text-red-500 text-sm mt-1">{errors.technicalSkills.message}</p>}
      </div>

      <div>
        <Label htmlFor="softSkills">Soft Skills *</Label>
        <Textarea
          id="softSkills"
          placeholder="e.g., Teamwork, Communication, Leadership"
          {...register("softSkills", { required: "Soft skills are required" })}
        />
        {errors.softSkills && <p className="text-red-500 text-sm mt-1">{errors.softSkills.message}</p>}
      </div>

      <div>
        <Label htmlFor="languageProficiency">Language Proficiency</Label>
        <Textarea
          id="languageProficiency"
          placeholder="e.g., English, Spanish, French"
          {...register("languageProficiency")}
        />
      </div>

      <div>
        <Label htmlFor="certifications">Certifications</Label>
        <Textarea
          id="certifications"
          placeholder="e.g., AWS Certified Developer, Google Analytics Certified"
          {...register("certifications")}
        />
      </div>

      <Button type="submit">Save Skills</Button>
    </form>
  )
}

