"use client"

import { useState } from "react"
import Image from "next/image"

type Template = {
  id: number
  name: string
  image: string
}

const templates: Template[] = [
  { id: 1, name: "Classic", image: "/templates/classic.png" },
  { id: 2, name: "Modern", image: "/templates/modern.png" },
  { id: 3, name: "Creative", image: "/templates/creative.png" },
  // Add more templates here, up to 20
]

type TemplateSelectorProps = {
  selectedTemplate: number
  onSelectTemplate: (templateId: number) => void
}

export default function TemplateSelector({ selectedTemplate, onSelectTemplate }: TemplateSelectorProps) {
  const [showAll, setShowAll] = useState(false)

  const displayedTemplates = showAll ? templates : templates.slice(0, 3)

  return (
    <div className="mt-6">
      <h2 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Select a Template</h2>
      <div className="grid grid-cols-3 gap-4">
        {displayedTemplates.map((template) => (
          <div
            key={template.id}
            className={`cursor-pointer border-2 rounded-lg overflow-hidden ${
              selectedTemplate === template.id ? "border-indigo-500" : "border-gray-200 dark:border-gray-700"
            }`}
            onClick={() => onSelectTemplate(template.id)}
          >
            <Image
              src={template.image || "/placeholder.svg"}
              alt={template.name}
              width={200}
              height={280}
              className="w-full h-auto"
            />
            <p className="text-center py-2 text-sm text-gray-700 dark:text-gray-300">{template.name}</p>
          </div>
        ))}
      </div>
      {!showAll && templates.length > 3 && (
        <button
          onClick={() => setShowAll(true)}
          className="mt-4 text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300"
        >
          Show all templates
        </button>
      )}
    </div>
  )
}

