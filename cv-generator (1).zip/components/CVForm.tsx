"use client"

import type React from "react"

import { useState } from "react"
import { toast } from "react-toastify"
import TemplateSelector from "./TemplateSelector"

type Education = {
  institution: string
  degree: string
  year: string
}

type Experience = {
  company: string
  position: string
  startDate: string
  endDate: string
  description: string
}

type FormData = {
  name: string
  email: string
  education: Education[]
  skills: string[]
  experience: Experience[]
  selectedTemplate: number
}

export default function CVForm() {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    education: [{ institution: "", degree: "", year: "" }],
    skills: [""],
    experience: [{ company: "", position: "", startDate: "", endDate: "", description: "" }],
    selectedTemplate: 1,
  })
  const [loading, setLoading] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }))
  }

  const handleEducationChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    const newEducation = [...formData.education]
    newEducation[index] = { ...newEducation[index], [name]: value }
    setFormData((prevData) => ({
      ...prevData,
      education: newEducation,
    }))
  }

  const handleSkillChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const newSkills = [...formData.skills]
    newSkills[index] = e.target.value
    setFormData((prevData) => ({
      ...prevData,
      skills: newSkills,
    }))
  }

  const handleExperienceChange = (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    const newExperience = [...formData.experience]
    newExperience[index] = { ...newExperience[index], [name]: value }
    setFormData((prevData) => ({
      ...prevData,
      experience: newExperience,
    }))
  }

  const addEducation = () => {
    setFormData((prevData) => ({
      ...prevData,
      education: [...prevData.education, { institution: "", degree: "", year: "" }],
    }))
  }

  const addSkill = () => {
    setFormData((prevData) => ({
      ...prevData,
      skills: [...prevData.skills, ""],
    }))
  }

  const addExperience = () => {
    setFormData((prevData) => ({
      ...prevData,
      experience: [...prevData.experience, { company: "", position: "", startDate: "", endDate: "", description: "" }],
    }))
  }

  const handleTemplateSelection = (templateId: number) => {
    setFormData((prevData) => ({
      ...prevData,
      selectedTemplate: templateId,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch("/api/generate-cv", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.style.display = "none"
        a.href = url
        a.download = "cv.pdf"
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        toast.success("CV generated successfully!")
      } else {
        toast.error("Failed to generate CV. Please try again.")
      }
    } catch (error) {
      console.error("Error generating CV:", error)
      toast.error("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Name
        </label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
        />
      </div>

      <div>
        <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Email
        </label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Education</label>
        {formData.education.map((edu, index) => (
          <div key={index} className="mt-2 space-y-2">
            <input
              type="text"
              name="institution"
              value={edu.institution}
              onChange={(e) => handleEducationChange(index, e)}
              placeholder="Institution"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
            <input
              type="text"
              name="degree"
              value={edu.degree}
              onChange={(e) => handleEducationChange(index, e)}
              placeholder="Degree"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
            <input
              type="text"
              name="year"
              value={edu.year}
              onChange={(e) => handleEducationChange(index, e)}
              placeholder="Year"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
          </div>
        ))}
        <button
          type="button"
          onClick={addEducation}
          className="mt-2 text-sm text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300"
        >
          Add Education
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Skills</label>
        {formData.skills.map((skill, index) => (
          <input
            key={index}
            type="text"
            value={skill}
            onChange={(e) => handleSkillChange(index, e)}
            placeholder="Skill"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
          />
        ))}
        <button
          type="button"
          onClick={addSkill}
          className="mt-2 text-sm text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300"
        >
          Add Skill
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Experience</label>
        {formData.experience.map((exp, index) => (
          <div key={index} className="mt-2 space-y-2">
            <input
              type="text"
              name="company"
              value={exp.company}
              onChange={(e) => handleExperienceChange(index, e)}
              placeholder="Company"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
            <input
              type="text"
              name="position"
              value={exp.position}
              onChange={(e) => handleExperienceChange(index, e)}
              placeholder="Position"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
            <input
              type="text"
              name="startDate"
              value={exp.startDate}
              onChange={(e) => handleExperienceChange(index, e)}
              placeholder="Start Date"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
            <input
              type="text"
              name="endDate"
              value={exp.endDate}
              onChange={(e) => handleExperienceChange(index, e)}
              placeholder="End Date"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
            <textarea
              name="description"
              value={exp.description}
              onChange={(e) => handleExperienceChange(index, e)}
              placeholder="Description"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
          </div>
        ))}
        <button
          type="button"
          onClick={addExperience}
          className="mt-2 text-sm text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300"
        >
          Add Experience
        </button>
      </div>

      <TemplateSelector selectedTemplate={formData.selectedTemplate} onSelectTemplate={handleTemplateSelection} />

      <div>
        <button
          type="submit"
          disabled={loading}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:bg-indigo-500 dark:hover:bg-indigo-600"
        >
          {loading ? "Generating..." : "Generate CV"}
        </button>
      </div>
    </form>
  )
}

