"use client"

import type React from "react"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { toast } from "react-toastify"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type BioDataFormData = {
  name: string
  email: string
  phone: string
  address: string
  nationality: string
  dateOfBirth: string
  gender: string
  maritalStatus: string
  profilePicture?: FileList
}

export default function BioDataForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<BioDataFormData>()
  const [profilePicture, setProfilePicture] = useState<string | null>(null)

  const onSubmit = (data: BioDataFormData) => {
    console.log(data)
    toast.success("Bio data saved successfully!")
  }

  const handleProfilePictureChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfilePicture(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="name">Name *</Label>
        <Input id="name" placeholder="Enter your full name" {...register("name", { required: "Name is required" })} />
        {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>}
      </div>

      <div>
        <Label htmlFor="email">Email *</Label>
        <Input
          id="email"
          type="email"
          placeholder="yourname@example.com"
          {...register("email", {
            required: "Email is required",
            pattern: { value: /^\S+@\S+$/i, message: "Invalid email address" },
          })}
        />
        {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
      </div>

      <div>
        <Label htmlFor="phone">Phone Number *</Label>
        <Input id="phone" placeholder="09012345678" {...register("phone", { required: "Phone number is required" })} />
        {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>}
      </div>

      <div>
        <Label htmlFor="address">Address *</Label>
        <Input
          id="address"
          placeholder="Enter your address"
          {...register("address", { required: "Address is required" })}
        />
        {errors.address && <p className="text-red-500 text-sm mt-1">{errors.address.message}</p>}
      </div>

      <div>
        <Label htmlFor="nationality">Nationality *</Label>
        <Input
          id="nationality"
          placeholder="Enter your nationality"
          {...register("nationality", { required: "Nationality is required" })}
        />
        {errors.nationality && <p className="text-red-500 text-sm mt-1">{errors.nationality.message}</p>}
      </div>

      <div>
        <Label htmlFor="dateOfBirth">Date of Birth *</Label>
        <Input
          id="dateOfBirth"
          placeholder="DD/MM/YYYY"
          {...register("dateOfBirth", { required: "Date of birth is required" })}
        />
        {errors.dateOfBirth && <p className="text-red-500 text-sm mt-1">{errors.dateOfBirth.message}</p>}
      </div>

      <div>
        <Label htmlFor="gender">Gender *</Label>
        <Select {...register("gender", { required: "Gender is required" })}>
          <SelectTrigger>
            <SelectValue placeholder="Select your gender" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="male">Male</SelectItem>
            <SelectItem value="female">Female</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
        {errors.gender && <p className="text-red-500 text-sm mt-1">{errors.gender.message}</p>}
      </div>

      <div>
        <Label htmlFor="maritalStatus">Marital Status *</Label>
        <Select {...register("maritalStatus", { required: "Marital status is required" })}>
          <SelectTrigger>
            <SelectValue placeholder="Select your marital status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="single">Single</SelectItem>
            <SelectItem value="married">Married</SelectItem>
            <SelectItem value="divorced">Divorced</SelectItem>
            <SelectItem value="widowed">Widowed</SelectItem>
          </SelectContent>
        </Select>
        {errors.maritalStatus && <p className="text-red-500 text-sm mt-1">{errors.maritalStatus.message}</p>}
      </div>

      <div>
        <Label htmlFor="profilePicture">Profile Picture *</Label>
        <Input
          id="profilePicture"
          type="file"
          accept="image/*"
          onChange={handleProfilePictureChange}
          {...register("profilePicture", { required: "Profile picture is required" })}
        />
        {errors.profilePicture && <p className="text-red-500 text-sm mt-1">{errors.profilePicture.message}</p>}
        {profilePicture && (
          <img
            src={profilePicture || "/placeholder.svg"}
            alt="Profile"
            className="mt-2 w-32 h-32 object-cover rounded-full"
          />
        )}
      </div>

      <Button type="submit">Save Bio Data</Button>
    </form>
  )
}

