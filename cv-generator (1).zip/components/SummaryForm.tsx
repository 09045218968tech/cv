"use client"

import { useForm } from "react-hook-form"
import { toast } from "react-toastify"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

type SummaryFormData = {
  summary: string
}

export default function SummaryForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SummaryFormData>()

  const onSubmit = (data: SummaryFormData) => {
    console.log(data)
    toast.success("Summary saved successfully!")
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="summary">Summary/Objective *</Label>
        <Textarea
          id="summary"
          placeholder="Enter your professional summary or objective"
          {...register("summary", { required: "Summary is required" })}
        />
        {errors.summary && <p className="text-red-500 text-sm mt-1">{errors.summary.message}</p>}
      </div>

      <Button type="submit">Save Summary</Button>
    </form>
  )
}

