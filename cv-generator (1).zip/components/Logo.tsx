import Image from "next/image"
import Link from "next/link"

export default function Logo() {
  return (
    <Link href="/" className="flex items-center space-x-2">
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/InShot_20241112_081358515-r2GvVpWKO2uFbAHu7VnfGVKPHHjFbB.png"
        alt="Adetops Logo"
        width={40}
        height={40}
        className="w-8 h-8 md:w-10 md:h-10"
        priority
      />
      <span className="text-xl md:text-2xl font-bold text-gray-800 dark:text-white">CV Generator</span>
    </Link>
  )
}

