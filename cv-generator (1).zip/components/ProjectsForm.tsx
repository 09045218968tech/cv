"use client"

import { useForm } from "react-hook-form"
import { toast } from "react-toastify"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

type ProjectsFormData = {
  projectName: string
  description: string
  url?: string
  technologiesUsed: string
  role: string
}

export default function ProjectsForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ProjectsFormData>()

  const onSubmit = (data: ProjectsFormData) => {
    console.log(data)
    toast.success("Project information saved successfully!")
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="projectName">Project Name *</Label>
        <Input
          id="projectName"
          placeholder="Enter project name"
          {...register("projectName", { required: "Project name is required" })}
        />
        {errors.projectName && <p className="text-red-500 text-sm mt-1">{errors.projectName.message}</p>}
      </div>

      <div>
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          placeholder="Enter project description"
          {...register("description", { required: "Description is required" })}
        />
        {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>}
      </div>

      <div>
        <Label htmlFor="url">URL</Label>
        <Input id="url" placeholder="(link unavailable)" {...register("url")} />
      </div>

      <div>
        <Label htmlFor="technologiesUsed">Technologies Used *</Label>
        <Input
          id="technologiesUsed"
          placeholder="Enter technologies used"
          {...register("technologiesUsed", { required: "Technologies used is required" })}
        />
        {errors.technologiesUsed && <p className="text-red-500 text-sm mt-1">{errors.technologiesUsed.message}</p>}
      </div>

      <div>
        <Label htmlFor="role">Role *</Label>
        <Input
          id="role"
          placeholder="Enter your role in the project"
          {...register("role", { required: "Role is required" })}
        />
        {errors.role && <p className="text-red-500 text-sm mt-1">{errors.role.message}</p>}
      </div>

      <Button type="submit">Save Project</Button>
    </form>
  )
}

