"use client"

import { useForm } from "react-hook-form"
import { toast } from "react-toastify"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

type ExperienceFormData = {
  jobTitle: string
  company: string
  date: string
  description: string
  achievements?: string
}

export default function ExperienceForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ExperienceFormData>()

  const onSubmit = (data: ExperienceFormData) => {
    console.log(data)
    toast.success("Experience information saved successfully!")
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="jobTitle">Job Title *</Label>
        <Input
          id="jobTitle"
          placeholder="Enter job title"
          {...register("jobTitle", { required: "Job title is required" })}
        />
        {errors.jobTitle && <p className="text-red-500 text-sm mt-1">{errors.jobTitle.message}</p>}
      </div>

      <div>
        <Label htmlFor="company">Company *</Label>
        <Input
          id="company"
          placeholder="Enter company name"
          {...register("company", { required: "Company is required" })}
        />
        {errors.company && <p className="text-red-500 text-sm mt-1">{errors.company.message}</p>}
      </div>

      <div>
        <Label htmlFor="date">Date *</Label>
        <Input id="date" placeholder="MM/YYYY - MM/YYYY" {...register("date", { required: "Date is required" })} />
        {errors.date && <p className="text-red-500 text-sm mt-1">{errors.date.message}</p>}
      </div>

      <div>
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          placeholder="Enter job description"
          {...register("description", { required: "Description is required" })}
        />
        {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>}
      </div>

      <div>
        <Label htmlFor="achievements">Achievements</Label>
        <Textarea id="achievements" placeholder="Enter achievements" {...register("achievements")} />
      </div>

      <Button type="submit">Save Experience</Button>
    </form>
  )
}

