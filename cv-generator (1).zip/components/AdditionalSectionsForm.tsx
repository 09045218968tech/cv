"use client"

import { useForm } from "react-hook-form"
import { toast } from "react-toastify"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

type AdditionalSectionsFormData = {
  awardsAndHonors?: string
  volunteerExperience?: string
  relevantToolsOrSoftware?: string
  professionalMemberships?: string
  references?: string
}

export default function AdditionalSectionsForm() {
  const { register, handleSubmit } = useForm<AdditionalSectionsFormData>()

  const onSubmit = (data: AdditionalSectionsFormData) => {
    console.log(data)
    toast.success("Additional information saved successfully!")
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="awardsAndHonors">Awards and Honors</Label>
        <Textarea id="awardsAndHonors" placeholder="Enter your awards and honors" {...register("awardsAndHonors")} />
      </div>

      <div>
        <Label htmlFor="volunteerExperience">Volunteer Experience</Label>
        <Textarea
          id="volunteerExperience"
          placeholder="Enter your volunteer experience"
          {...register("volunteerExperience")}
        />
      </div>

      <div>
        <Label htmlFor="relevantToolsOrSoftware">Relevant Tools or Software</Label>
        <Input
          id="relevantToolsOrSoftware"
          placeholder="Enter relevant tools or software"
          {...register("relevantToolsOrSoftware")}
        />
      </div>

      <div>
        <Label htmlFor="professionalMemberships">Professional Memberships</Label>
        <Input
          id="professionalMemberships"
          placeholder="Enter professional memberships"
          {...register("professionalMemberships")}
        />
      </div>

      <div>
        <Label htmlFor="references">References</Label>
        <Textarea
          id="references"
          placeholder="Enter references (or 'Available upon request')"
          {...register("references")}
        />
      </div>

      <Button type="submit">Save Additional Information</Button>
    </form>
  )
}

