"use client"

import { useForm } from "react-hook-form"
import { toast } from "react-toastify"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

type EducationFormData = {
  degree: string
  institution: string
  date: string
  fieldOfStudy: string
  relevantCoursework?: string
}

export default function EducationForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<EducationFormData>()

  const onSubmit = (data: EducationFormData) => {
    console.log(data)
    toast.success("Education information saved successfully!")
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="degree">Degree *</Label>
        <Input
          id="degree"
          placeholder="e.g., Bachelor's, Master's, Ph.D."
          {...register("degree", { required: "Degree is required" })}
        />
        {errors.degree && <p className="text-red-500 text-sm mt-1">{errors.degree.message}</p>}
      </div>

      <div>
        <Label htmlFor="institution">Institution *</Label>
        <Input
          id="institution"
          placeholder="Enter institution name"
          {...register("institution", { required: "Institution is required" })}
        />
        {errors.institution && <p className="text-red-500 text-sm mt-1">{errors.institution.message}</p>}
      </div>

      <div>
        <Label htmlFor="date">Date *</Label>
        <Input id="date" placeholder="MM/YYYY - MM/YYYY" {...register("date", { required: "Date is required" })} />
        {errors.date && <p className="text-red-500 text-sm mt-1">{errors.date.message}</p>}
      </div>

      <div>
        <Label htmlFor="fieldOfStudy">Field of Study *</Label>
        <Input
          id="fieldOfStudy"
          placeholder="Enter field of study"
          {...register("fieldOfStudy", { required: "Field of study is required" })}
        />
        {errors.fieldOfStudy && <p className="text-red-500 text-sm mt-1">{errors.fieldOfStudy.message}</p>}
      </div>

      <div>
        <Label htmlFor="relevantCoursework">Relevant Coursework</Label>
        <Textarea id="relevantCoursework" placeholder="Enter relevant coursework" {...register("relevantCoursework")} />
      </div>

      <Button type="submit">Save Education</Button>
    </form>
  )
}

