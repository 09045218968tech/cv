"use client"

import { useState, useEffect } from "react"
import { ToastContainer, toast } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import BioDataForm from "@/components/BioDataForm"
import ContactForm from "@/components/ContactForm"
import SkillsForm from "@/components/SkillsForm"
import EducationForm from "@/components/EducationForm"
import ExperienceForm from "@/components/ExperienceForm"
import ProjectsForm from "@/components/ProjectsForm"
import SummaryForm from "@/components/SummaryForm"
import AdditionalSectionsForm from "@/components/AdditionalSectionsForm"
import { Button } from "@/components/ui/button"
import Logo from "@/components/Logo"

export default function CreateCVPage() {
  const [activeTab, setActiveTab] = useState("bio-data")
  const [templateId, setTemplateId] = useState<number | null>(null)
  const [customization, setCustomization] = useState<any>(null)

  useEffect(() => {
    const storedTemplateId = localStorage.getItem("selectedTemplateId")
    const storedCustomization = localStorage.getItem("templateCustomization")

    if (storedTemplateId) {
      setTemplateId(Number.parseInt(storedTemplateId, 10))
    }

    if (storedCustomization) {
      setCustomization(JSON.parse(storedCustomization))
    }
  }, [])

  const tabs = [
    { id: "bio-data", label: "Bio Data" },
    { id: "contact", label: "Contact" },
    { id: "skills", label: "Skills" },
    { id: "education", label: "Education" },
    { id: "experience", label: "Experience" },
    { id: "projects", label: "Projects" },
    { id: "summary", label: "Summary" },
    { id: "additional", label: "Additional" },
  ]

  const handleGenerateCV = async () => {
    // Collect all form data
    // Generate CV using selected template and customizations
    // Implement CV generation logic here
    toast.success("CV generated successfully!")
  }

  const handleDownloadCV = async (format: "pdf" | "docx" | "txt") => {
    // Implement download logic for different formats
    toast.success(`CV downloaded as ${format.toUpperCase()}`)
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow">
        <nav className="container mx-auto px-6 py-3">
          <div className="flex justify-between items-center">
            <Logo />
            <Link href="/">
              <Button variant="outline">Home</Button>
            </Link>
          </div>
        </nav>
      </header>
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Create Your CV</h1>
        {templateId && <p className="mb-4">Selected Template: Template {templateId}</p>}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            {tabs.map((tab) => (
              <TabsTrigger key={tab.id} value={tab.id}>
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>
          <TabsContent value="bio-data">
            <BioDataForm />
          </TabsContent>
          <TabsContent value="contact">
            <ContactForm />
          </TabsContent>
          <TabsContent value="skills">
            <SkillsForm />
          </TabsContent>
          <TabsContent value="education">
            <EducationForm />
          </TabsContent>
          <TabsContent value="experience">
            <ExperienceForm />
          </TabsContent>
          <TabsContent value="projects">
            <ProjectsForm />
          </TabsContent>
          <TabsContent value="summary">
            <SummaryForm />
          </TabsContent>
          <TabsContent value="additional">
            <AdditionalSectionsForm />
          </TabsContent>
        </Tabs>
        <div className="mt-8 flex justify-between">
          <Button
            onClick={() => {
              const currentIndex = tabs.findIndex((tab) => tab.id === activeTab)
              if (currentIndex > 0) {
                setActiveTab(tabs[currentIndex - 1].id)
              }
            }}
            disabled={activeTab === tabs[0].id}
          >
            Previous
          </Button>
          <Button
            onClick={() => {
              const currentIndex = tabs.findIndex((tab) => tab.id === activeTab)
              if (currentIndex < tabs.length - 1) {
                setActiveTab(tabs[currentIndex + 1].id)
              }
            }}
            disabled={activeTab === tabs[tabs.length - 1].id}
          >
            Next
          </Button>
        </div>
        <div className="mt-8 space-y-4">
          <Button onClick={handleGenerateCV} className="w-full">
            Generate CV
          </Button>
          <div className="flex justify-between">
            <Button onClick={() => handleDownloadCV("pdf")} variant="outline">
              Download PDF
            </Button>
            <Button onClick={() => handleDownloadCV("docx")} variant="outline">
              Download Word
            </Button>
            <Button onClick={() => handleDownloadCV("txt")} variant="outline">
              Download Text
            </Button>
          </div>
        </div>
      </main>
      <ToastContainer />
    </div>
  )
}

