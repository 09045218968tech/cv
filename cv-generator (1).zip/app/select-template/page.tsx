"use client"

import { useState } from "react"
import { TemplatePreview } from "@/components/TemplatePreview"
import { Button } from "@/components/ui/button"
import Link from "next/link"

// Mock data for templates (replace with actual data later)
const templates = Array.from({ length: 30 }, (_, i) => ({
  id: i + 1,
  name: `Template ${i + 1}`,
  image: `/templates/template-${i + 1}.jpg`,
}))

export default function SelectTemplatePage() {
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null)

  const handleSelectTemplate = (id: number) => {
    setSelectedTemplate(id)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Select a Template</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map((template) => (
          <TemplatePreview
            key={template.id}
            id={template.id}
            name={template.name}
            image={template.image}
            onSelect={handleSelectTemplate}
          />
        ))}
      </div>
      {selectedTemplate && (
        <div className="mt-8 text-center">
          <Link href={`/customize-template/${selectedTemplate}`}>
            <Button>Customize Template</Button>
          </Link>
        </div>
      )}
    </div>
  )
}

