import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Logo from "@/components/Logo"
import { TemplatePreview } from "@/components/TemplatePreview"

// Mock data for featured templates (replace with actual data later)
const featuredTemplates = Array.from({ length: 6 }, (_, i) => ({
  id: i + 1,
  name: `Template ${i + 1}`,
  image: `/templates/template-${i + 1}.jpg`,
}))

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow">
        <nav className="container mx-auto px-6 py-3">
          <div className="flex justify-between items-center">
            <Logo />
            <Link href="/select-template">
              <Button>Create CV</Button>
            </Link>
          </div>
        </nav>
      </header>

      <main className="container mx-auto px-6 py-8">
        <section className="mb-16 text-center">
          <h1 className="text-4xl font-bold mb-4 text-gray-900 dark:text-white">
            Create Your Professional CV in Minutes
          </h1>
          <p className="text-xl mb-6 text-gray-700 dark:text-gray-300">
            Choose from 30+ professionally designed templates and customize your CV to stand out from the crowd.
          </p>
          <Link href="/select-template">
            <Button size="lg" className="text-lg px-8 py-4">
              Get Started
              <ArrowRight className="ml-2" />
            </Button>
          </Link>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">Featured Templates</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredTemplates.map((template) => (
              <TemplatePreview
                key={template.id}
                id={template.id}
                name={template.name}
                image={template.image}
                onSelect={() => {}}
              />
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link href="/select-template">
              <Button variant="outline">View All Templates</Button>
            </Link>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: "Choose a Template", description: "Browse our collection of 30+ professional templates" },
              { title: "Fill in Your Details", description: "Enter your information in our easy-to-use form" },
              { title: "Download Your CV", description: "Generate and download your CV in multiple formats" },
            ].map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-indigo-600 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                  {index + 1}
                </div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-700 dark:text-gray-300">{step.description}</p>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="bg-white dark:bg-gray-800 shadow mt-16">
        <div className="container mx-auto px-6 py-4">
          <p className="text-center text-gray-700 dark:text-gray-300">
            © {new Date().getFullYear()} CV Generator by Adetops. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

