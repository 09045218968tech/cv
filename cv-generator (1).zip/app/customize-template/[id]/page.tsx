"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CustomizationOptions = {
  colorScheme: string
  font: string
  layout: string
}

export default function CustomizeTemplatePage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [customization, setCustomization] = useState<CustomizationOptions>({
    colorScheme: "default",
    font: "default",
    layout: "default",
  })

  const handleCustomizationChange = (key: keyof CustomizationOptions, value: string) => {
    setCustomization((prev) => ({ ...prev, [key]: value }))
  }

  const handleSubmit = () => {
    // Save customization options and navigate to CV creation page
    localStorage.setItem("templateCustomization", JSON.stringify(customization))
    router.push("/create-cv")
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Customize Template {params.id}</h1>
      <div className="space-y-6">
        <div>
          <Label htmlFor="colorScheme">Color Scheme</Label>
          <Select
            value={customization.colorScheme}
            onValueChange={(value) => handleCustomizationChange("colorScheme", value)}
          >
            <SelectTrigger id="colorScheme">
              <SelectValue placeholder="Select color scheme" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default">Default</SelectItem>
              <SelectItem value="blue">Blue</SelectItem>
              <SelectItem value="green">Green</SelectItem>
              <SelectItem value="red">Red</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="font">Font</Label>
          <Select value={customization.font} onValueChange={(value) => handleCustomizationChange("font", value)}>
            <SelectTrigger id="font">
              <SelectValue placeholder="Select font" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default">Default</SelectItem>
              <SelectItem value="serif">Serif</SelectItem>
              <SelectItem value="sans-serif">Sans-serif</SelectItem>
              <SelectItem value="monospace">Monospace</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="layout">Layout</Label>
          <Select value={customization.layout} onValueChange={(value) => handleCustomizationChange("layout", value)}>
            <SelectTrigger id="layout">
              <SelectValue placeholder="Select layout" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default">Default</SelectItem>
              <SelectItem value="compact">Compact</SelectItem>
              <SelectItem value="spacious">Spacious</SelectItem>
              <SelectItem value="modern">Modern</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={handleSubmit}>Apply Customization</Button>
      </div>
    </div>
  )
}

